# CEC Audio Toggle Controller

A compiled C binary that runs on a **Raspberry Pi 4B** and uses physical GPIO
buttons to toggle TV audio output between an HDMI soundbar and the TV's built-in
speakers — over HDMI-CEC with **no extra hardware** beyond the buttons.

The code uses a clean HAL (Hardware Abstraction Layer) so the same `main.c`
logic can be **ported directly to ESP32** by swapping only the two HAL files.

---

## Verified Hardware

| Device | Details |
|--------|---------|
| Raspberry Pi | Pi 4B Rev 1.4, kernel 6.12.62+rpt-rpi-v8 |
| TV | LG (CEC vendor 0x00e091), logical addr 0x0, physical 0.0.0.0 |
| Soundbar | CINEMA SB590, logical addr 0x5, physical 2.0.0.0 |
| HDMI | Pi HDMI port 1 → TV (Pi physical addr: 1.0.0.0) |

---

## Project Structure

```
cec_controller/
├── README.md                   ← this file
├── Makefile                    ← build + install
├── cec_controller.h            ← shared types + HAL interface
├── main.c                      ← platform-agnostic app logic
├── deploy_to_pi.sh             ← one-command deploy from Mac → Pi
├── pi_cec_controller.service   ← systemd unit for auto-start on boot
└── hal/
    ├── cec_hal_linux.c         ← Pi: /dev/cec0 via kernel CEC API
    ├── gpio_hal_linux.c        ← Pi: libgpiod 1.x button input
    ├── cec_hal_esp32.c         ← ESP32 port stub
    └── gpio_hal_esp32.c        ← ESP32 port stub
```

---

## Button Wiring (Pi 4B 40-pin header)

All buttons are **active-LOW** — wire between GPIO pin and GND.
No resistors needed (internal pull-ups enabled in software).

```
Pi 40-pin header

  3V3  [ 1][ 2]  5V
GPIO2  [ 3][ 4]  5V
GPIO3  [ 5][ 6]  GND
GPIO4  [ 7][ 8]  GPIO14
  GND  [ 9][10]  GPIO15
GPIO17 [11][12]  GPIO18    ← Pin 11 = SOUNDBAR button
GPIO27 [13][14]  GND       ← Pin 13 = TV SPEAKERS button
GPIO22 [15][16]  GPIO23    ← Pin 15 = VOLUME DOWN button
```

| Button | BCM GPIO | Physical Pin | → Wire to |
|--------|----------|--------------|-----------|
| **SOUNDBAR** (SAM ON) | GPIO17 | **Pin 11** | Pin 9 GND |
| **TV SPEAKERS** (SAM OFF) | GPIO27 | **Pin 13** | Pin 14 GND |
| **VOLUME DOWN** | GPIO22 | **Pin 15** | Pin 14 GND |

```
Pin 11 (GPIO17) ──[BTN1 SOUNDBAR ]──┐
Pin 13 (GPIO27) ──[BTN2 TV SPKRS ]──┼── GND (Pin 9 or 14)
Pin 15 (GPIO22) ──[BTN3 VOL DOWN ]──┘
```

---

## How It Works (CEC Protocol)

### SAM ON — Audio → Soundbar
```
TX  [05 70 10 00]   TV(0)→Soundbar(5)   SYSTEM_AUDIO_MODE_REQUEST  phys=1.0.0.0
RX  [5F 72 01]      Soundbar(5)→all     SET_SYSTEM_AUDIO_MODE ON   ✓ confirmed
```
The soundbar only obeys SAM_REQUEST from TV logical address 0x0.
CEC_MSG_FL_RAW allows the Pi to spoof that address (requires root).

### SAM OFF — Audio → TV Speakers
```
TX  [5F 72 00]      spoof Soundbar(5)→all   SET_SYSTEM_AUDIO_MODE OFF
TX  [0F 72 00]      TV(0)→all               SET_SYSTEM_AUDIO_MODE OFF
TX  [0F 82 00 00]   TV(0)→all               ACTIVE_SOURCE(0.0.0.0)
```
CINEMA SB590 ignores SAM_REQUEST(phys=0). Spoofing the soundbar declaring
SAM OFF is the only reliable method verified on this hardware combination.

---

## Building on the Raspberry Pi

### Install dependencies (once)
```bash
sudo apt-get install -y libgpiod-dev gcc
```

### Build
```bash
cd ~/cec_controller
make
# Output: ./cec_controller  (~35 KB binary)
```

### Run manually (for testing)
```bash
sudo ./cec_controller /dev/cec0
```

### Install as systemd service (auto-start on boot)
```bash
sudo make install
```

### Service management
```bash
sudo systemctl status  pi-cec-controller       # check running status
sudo systemctl restart pi-cec-controller       # restart
sudo systemctl stop    pi-cec-controller       # stop
sudo journalctl -u pi-cec-controller -f        # live log
```

### Uninstall
```bash
sudo make uninstall
```

---

## Deploy from macOS (One Command)

From the `esp32/` workspace root on your Mac:

```bash
./tools/cec_controller/deploy_to_pi.sh apoorv@192.168.0.120
```

This will:
1. Package all source files into `cec_controller_src.tar.gz`
2. Copy archive to the Pi via scp
3. Extract and run `make clean && make` on the Pi
4. Run `sudo make install` to install the systemd service

---

## Software Testing (No Buttons Needed)

```bash
# Get service PID
PID=$(ssh apoorv@192.168.0.120 \
  'systemctl show pi-cec-controller --property=MainPID --value')

# Toggle audio (soundbar ↔ TV)
ssh apoorv@192.168.0.120 "sudo kill -USR1 $PID"

# Force audio → TV speakers
ssh apoorv@192.168.0.120 "sudo kill -USR2 $PID"

# Watch live
ssh apoorv@192.168.0.120 "sudo journalctl -u pi-cec-controller -f"
```

---

## Expected Log Output

**SOUNDBAR button pressed:**
```
[BTN] SOUNDBAR pressed
[APP] ▶  Audio → SOUNDBAR (SAM ON)
[CEC] TX  TV→AudioSys  SAM_REQUEST   [05 70 10 00]
[CEC] RX  AudioSys→all SET_SAM       [5F 72 01]
[APP] ✓  Soundbar confirmed SAM ON
```

**TV SPEAKERS button pressed:**
```
[BTN] TV SPEAKERS pressed
[APP] ◀  Audio → TV SPEAKERS (SAM OFF)
[CEC] TX  AudioSys→all SET_SAM       [5F 72 00]
[CEC] TX  TV→all       SET_SAM       [0F 72 00]
[CEC] TX  TV→all       ACTIVE_SOURCE [0F 82 00 00]
[APP] ✓  Audio → TV speakers
```

---

## Porting to ESP32

`main.c` is 100% platform-agnostic. Only two HAL files change.

### Steps
1. Copy `cec_controller/` into PlatformIO `src/`
2. Add to `platformio.ini`:
   ```ini
   build_flags = -DPLATFORM_ESP32 -DCEC_GPIO_PIN=4
   ```
3. The ESP32 HAL stubs are ready in `hal/cec_hal_esp32.c` and `hal/gpio_hal_esp32.c`
4. `sendRaw()` is already added to `lib/ESP32_CEC/ESP32_CEC.h/.cpp`

### ESP32 button pins
| Function | GPIO |
|----------|------|
| SOUNDBAR | GPIO13 |
| TV SPEAKERS | GPIO14 |
| VOLUME DOWN | GPIO15 |

### ESP32 CEC wiring
```
ESP32 GPIO4 ──[4.7kΩ]──► HDMI Pin 13 (CEC line)
ESP32 GND              ──► HDMI Pin 17 (GND)
```

---

## Key CEC Implementation Notes

| Topic | Detail |
|-------|--------|
| Pi logical addr | 0xF (Unregistered — vc4 driver, cannot change) |
| Why root is required | `CEC_MSG_FL_RAW` flag to spoof TV src address |
| Why blocking fd | `O_NONBLOCK` returns tx_status=0 before bus completes |
| Soundbar addr | 0x5 (confirmed by `cec-client` scan) |
| TV addr | 0x0 |
| Pi HDMI physical addr | 1.0.0.0 (port 1 on TV) |
