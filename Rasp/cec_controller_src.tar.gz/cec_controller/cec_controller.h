/**
 * cec_controller.h
 * ─────────────────────────────────────────────────────────────────────────────
 * Shared types and HAL (Hardware Abstraction Layer) interface.
 *
 * Platform implementations:
 *   Raspberry Pi  → hal/cec_hal_linux.c   + hal/gpio_hal_linux.c
 *   ESP32         → hal/cec_hal_esp32.c   + hal/gpio_hal_esp32.c
 *
 * To port to ESP32:
 *   1. Copy this project into your PlatformIO src/ folder.
 *   2. Set PLATFORM_ESP32 in your build flags.
 *   3. Fill in hal/cec_hal_esp32.c  (bit-bang GPIO4, same sequences as Linux).
 *   4. Fill in hal/gpio_hal_esp32.c (digitalRead / INPUT_PULLUP).
 *   5. Remove Makefile; use platformio.ini.
 */

#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ── CEC logical addresses ──────────────────────────────────────────────── */
#define CEC_ADDR_TV           0x00
#define CEC_ADDR_AUDIO_SYSTEM 0x05   /* CINEMA SB590 */
#define CEC_ADDR_BROADCAST    0x0F

/* ── CEC opcodes ────────────────────────────────────────────────────────── */
#define CEC_OP_IMAGE_VIEW_ON      0x04
#define CEC_OP_STANDBY            0x36
#define CEC_OP_UCP                0x44   /* USER_CONTROL_PRESSED  */
#define CEC_OP_UCR                0x45   /* USER_CONTROL_RELEASED */
#define CEC_OP_SAM_REQUEST        0x70   /* SYSTEM_AUDIO_MODE_REQUEST */
#define CEC_OP_SET_SAM            0x72   /* SET_SYSTEM_AUDIO_MODE     */
#define CEC_OP_ACTIVE_SOURCE      0x82

/* ── CEC user-control codes ─────────────────────────────────────────────── */
#define CEC_UI_VOL_UP   0x41
#define CEC_UI_VOL_DN   0x42
#define CEC_UI_MUTE     0x43
#define CEC_UI_POWER    0x40

/* ── Application state ──────────────────────────────────────────────────── */
typedef struct {
    bool  system_audio_on;   /* true = soundbar active, false = TV speakers */
    int   volume;            /* 0–100 estimated level                        */
} app_state_t;

/* ═══════════════════════════════════════════════════════════════════════════
 *  CEC HAL  —  implement in hal/cec_hal_linux.c  OR  hal/cec_hal_esp32.c
 * ═══════════════════════════════════════════════════════════════════════════ */

/** Open the CEC adapter. Returns 0 on success, -1 on error. */
int  cec_hal_open(const char *device);

/** Close the CEC adapter. */
void cec_hal_close(void);

/**
 * Transmit a raw CEC frame.
 *   data[0]  = header byte  (src<<4 | dst)
 *   data[1]  = opcode
 *   data[2+] = parameters (optional)
 *   reply_op = opcode to wait for as reply (0 = no wait)
 * Returns true if TX succeeded (and reply received when reply_op != 0).
 */
bool cec_hal_tx(const uint8_t *data, uint8_t len, uint8_t reply_op);

/* ═══════════════════════════════════════════════════════════════════════════
 *  GPIO HAL  —  implement in hal/gpio_hal_linux.c  OR  hal/gpio_hal_esp32.c
 * ═══════════════════════════════════════════════════════════════════════════ */

/** GPIO pin IDs — logical names, mapped to physical pins in each HAL.
 *
 *  Pi wiring:
 *    GPIO17 (Pin 11) ──[BTN]── GND  →  SOUNDBAR  (SAM ON)
 *    GPIO27 (Pin 13) ──[BTN]── GND  →  TV SPEAKERS (SAM OFF)
 *    GPIO22 (Pin 15) ──[BTN]── GND  →  VOLUME DOWN
 */
typedef enum {
    GPIO_BTN_SOUNDBAR  = 0,   /* dedicated: route audio → soundbar    */
    GPIO_BTN_TV        = 1,   /* dedicated: route audio → TV speakers */
    GPIO_BTN_VOL_DOWN  = 2,   /* volume down                           */
    GPIO_COUNT         = 3,
} gpio_btn_t;

/** Button event callback — fired on every confirmed button press. */
typedef void (*gpio_btn_callback_t)(gpio_btn_t btn);

/**
 * Initialise GPIO inputs.
 * All buttons are active-LOW with internal pull-ups.
 * cb is called (from the main poll loop) on each debounced press.
 * Returns 0 on success, -1 on error.
 */
int  gpio_hal_init(gpio_btn_callback_t cb);

/** Poll for button events. Call repeatedly from main loop. */
void gpio_hal_poll(void);

/** Release GPIO resources. */
void gpio_hal_close(void);
