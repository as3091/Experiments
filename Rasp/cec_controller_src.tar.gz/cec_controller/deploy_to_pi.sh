#!/usr/bin/env bash
# deploy_to_pi.sh — Build and deploy cec_controller to Raspberry Pi
# Usage:  ./tools/cec_controller/deploy_to_pi.sh [user@host]
# Run from esp32/ workspace root OR from inside cec_controller/.
# Default target: apoorv@192.168.0.120

set -euo pipefail

PI_TARGET="${1:-apoorv@192.168.0.120}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE="/tmp/cec_controller.tar.gz"

echo "════════════════════════════════════════"
echo "  CEC Controller — Deploy to Pi"
echo "  Target : $PI_TARGET"
echo "════════════════════════════════════════"

# 1. Package
echo "▶  Packaging source..."
cd "$SRC_DIR/.."
tar -czf "$ARCHIVE" \
    --exclude='*.o' \
    --exclude='cec_controller/cec_controller' \
    --exclude='.DS_Store' \
    cec_controller/
echo "   Archive: $ARCHIVE ($(du -sh "$ARCHIVE" | cut -f1))"

# 2. Copy to Pi
echo "▶  Copying to Pi..."
scp "$ARCHIVE" "$PI_TARGET:/tmp/cec_controller.tar.gz"

# 3. Build and install on Pi
echo "▶  Building on Pi..."
ssh "$PI_TARGET" bash << 'REMOTE'
set -e
rm -rf ~/cec_controller
tar -xzf /tmp/cec_controller.tar.gz -C ~/
rm /tmp/cec_controller.tar.gz
dpkg -l libgpiod-dev &>/dev/null || sudo apt-get install -y libgpiod-dev
cd ~/cec_controller
make clean && make
sudo make install
sleep 2
echo "--- Service status ---"
sudo systemctl status pi-cec-controller --no-pager | head -10
REMOTE

echo ""
echo "════════════════════════════════════════"
echo "  ✅  Deploy complete!"
echo ""
echo "  Live log:"
echo "    ssh $PI_TARGET 'sudo journalctl -u pi-cec-controller -f'"
echo ""
echo "  Software toggle test:"
echo "    PID=\$(ssh $PI_TARGET 'systemctl show pi-cec-controller --property=MainPID --value')"
echo "    ssh $PI_TARGET \"sudo kill -USR1 \$PID\"   # soundbar"
echo "    ssh $PI_TARGET \"sudo kill -USR2 \$PID\"   # TV speakers"
echo "════════════════════════════════════════"
