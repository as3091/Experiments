/**
 * hal/gpio_hal_esp32.c
 * ─────────────────────────────────────────────────────────────────────────────
 * GPIO HAL stub for ESP32 (PlatformIO / Arduino framework).
 *
 * Button wiring (same logical mapping as Pi):
 *   GPIO13 ──[button]── GND  → GPIO_BTN_SOUNDBAR   (SAM ON)
 *   GPIO14 ──[button]── GND  → GPIO_BTN_TV         (SAM OFF)
 *   GPIO15 ──[button]── GND  → GPIO_BTN_VOL_DOWN
 *
 * gpio_hal_poll() must be called every loop() iteration.
 * Debounce is handled here — same 300 ms window as the Pi HAL.
 */

#ifdef PLATFORM_ESP32
#include "../cec_controller.h"
#include <Arduino.h>

/* ── Pin assignments ─────────────────────────────────────────────────────── */
static const uint8_t PIN_MAP[GPIO_COUNT] = {
    [GPIO_BTN_SOUNDBAR]  = 13,   /* → SAM ON  */
    [GPIO_BTN_TV]        = 14,   /* → SAM OFF */
    [GPIO_BTN_VOL_DOWN]  = 15,   /* → Vol-    */
};

#define DEBOUNCE_MS  300

static gpio_btn_callback_t _cb = NULL;
static bool     _last_state[GPIO_COUNT];
static uint32_t _last_press_ms[GPIO_COUNT];

int gpio_hal_init(gpio_btn_callback_t cb) {
    _cb = cb;
    for (int i = 0; i < GPIO_COUNT; i++) {
        pinMode(PIN_MAP[i], INPUT_PULLUP);
        _last_state[i]    = HIGH;
        _last_press_ms[i] = 0;
        Serial.printf("[GPIO] GPIO%d → btn %d\n", PIN_MAP[i], i);
    }
    return 0;
}

void gpio_hal_poll(void) {
    for (int i = 0; i < GPIO_COUNT; i++) {
        bool now = digitalRead(PIN_MAP[i]);
        /* Falling edge (HIGH→LOW) = button pressed */
        if (now == LOW && _last_state[i] == HIGH) {
            uint32_t t = millis();
            if ((t - _last_press_ms[i]) >= DEBOUNCE_MS) {
                _last_press_ms[i] = t;
                if (_cb) _cb((gpio_btn_t)i);
            }
        }
        _last_state[i] = now;
    }
}

void gpio_hal_close(void) {
    /* nothing to release on ESP32 */
}
#endif /* PLATFORM_ESP32 */
