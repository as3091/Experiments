/**
 * hal/cec_hal_linux.c
 * ─────────────────────────────────────────────────────────────────────────────
 * CEC HAL implementation for Raspberry Pi (Linux /dev/cec0).
 *
 * Key findings (verified on LG TV + CINEMA SB590, Pi kernel 6.12):
 *   • Pi vc4 driver claims logical addr 0xF (Unregistered) — cannot change.
 *   • Soundbar ONLY responds to SAM_REQUEST from TV addr (0x0).
 *   • CEC_MSG_FL_RAW (0x02) bypasses kernel src-addr check → allows spoofing.
 *   • FL_RAW requires the process to run as root.
 *   • fd MUST be opened O_RDWR (blocking) — O_NONBLOCK breaks TX sync.
 */

#include "../cec_controller.h"

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <linux/cec.h>      /* struct cec_msg, CEC_TRANSMIT, etc. */

/* ── ioctl numbers — guard against redefinition from linux/cec.h ─────────── */
#ifndef CEC_ADAP_S_MODE
#  define CEC_ADAP_S_MODE  _IOW('a', 9,  __u32)
#endif
#ifndef CEC_TRANSMIT
#  define CEC_TRANSMIT     _IOWR('a', 5, struct cec_msg)
#endif
#ifndef CEC_MSG_FL_RAW
#  define CEC_MSG_FL_RAW   0x02
#endif
#ifndef CEC_MODE_INITIATOR
#  define CEC_MODE_INITIATOR  0x01
#endif
#ifndef CEC_MODE_FOLLOWER
#  define CEC_MODE_FOLLOWER   0x10
#endif

/* Human-readable address names for log output */
static const char *_addr_name(uint8_t a) {
    static const char *names[] = {
        "TV","Rec1","Rec2","Tuner1","Play1","AudioSys","Tuner2","Tuner3",
        "Play2","Rec3","Tuner4","Play3","?","?","FreeUse","Bcast/Unreg"
    };
    return (a < 16) ? names[a] : "?";
}
static const char *_op_name(uint8_t op) {
    switch (op) {
        case 0x04: return "IMAGE_VIEW_ON";
        case 0x36: return "STANDBY";
        case 0x44: return "UCP";
        case 0x45: return "UCR";
        case 0x70: return "SAM_REQUEST";
        case 0x72: return "SET_SAM";
        case 0x82: return "ACTIVE_SOURCE";
        default: {
            static char buf[8];
            snprintf(buf, sizeof(buf), "0x%02X", op);
            return buf;
        }
    }
}

static int _fd = -1;

/* ── Open ─────────────────────────────────────────────────────────────────── */
int cec_hal_open(const char *device) {
    _fd = open(device, O_RDWR);   /* BLOCKING — O_NONBLOCK breaks TX */
    if (_fd < 0) {
        fprintf(stderr, "[CEC] open(%s): %s\n", device, strerror(errno));
        return -1;
    }

    /* Set initiator + follower mode */
    uint32_t mode = CEC_MODE_INITIATOR | CEC_MODE_FOLLOWER;
    if (ioctl(_fd, CEC_ADAP_S_MODE, &mode) < 0)
        fprintf(stderr, "[CEC] S_MODE warning: %s\n", strerror(errno));

    printf("[CEC] Opened %s (fd=%d, FL_RAW spoofing active)\n", device, _fd);
    return 0;
}

/* ── Close ────────────────────────────────────────────────────────────────── */
void cec_hal_close(void) {
    if (_fd >= 0) { close(_fd); _fd = -1; }
}

/* ── Transmit ─────────────────────────────────────────────────────────────── */
bool cec_hal_tx(const uint8_t *data, uint8_t len, uint8_t reply_op) {
    if (_fd < 0 || len == 0) return false;

    struct cec_msg m;
    memset(&m, 0, sizeof(m));
    m.len     = len;
    m.timeout = 3000;          /* ms — wait up to 3 s for reply  */
    m.reply   = reply_op;
    m.flags   = CEC_MSG_FL_RAW;  /* allows spoofed src addr; needs root */
    memcpy(m.msg, data, len);

    uint8_t src = (data[0] >> 4) & 0xF;
    uint8_t dst =  data[0]       & 0xF;
    uint8_t op  = (len > 1) ? data[1] : 0xFF;

    /* Print raw hex for easy cross-checking with cec-client */
    char hex[48] = {0};
    for (int i = 0; i < len && i < 16; i++)
        snprintf(hex + i*3, 4, "%02X ", data[i]);

    printf("[CEC] TX  %s→%s  %-16s  [%s]\n",
           _addr_name(src), _addr_name(dst), _op_name(op), hex);
    fflush(stdout);

    if (ioctl(_fd, CEC_TRANSMIT, &m) < 0) {
        if (errno == EPERM)
            fprintf(stderr, "[CEC] TX EPERM — run as root (needed for FL_RAW)\n");
        else
            fprintf(stderr, "[CEC] TX ioctl: %s\n", strerror(errno));
        return false;
    }

    bool tx_ok   = (m.tx_status & CEC_TX_STATUS_OK)   != 0;
    bool tx_nack = (m.tx_status & CEC_TX_STATUS_NACK)  != 0;
    bool rx_ok   = (m.rx_status & CEC_RX_STATUS_OK)    != 0;

    if (tx_nack) {
        printf("[CEC]   NACK — %s not responding\n", _addr_name(dst));
        return false;
    }
    if (!tx_ok)
        printf("[CEC]   tx_status=0x%02X\n", m.tx_status);

    if (rx_ok && reply_op) {
        char rhex[48] = {0};
        for (int i = 0; i < (int)m.len && i < 16; i++)
            snprintf(rhex + i*3, 4, "%02X ", m.msg[i]);
        uint8_t rsrc = (m.msg[0] >> 4) & 0xF;
        uint8_t rdst =  m.msg[0]       & 0xF;
        uint8_t rop  = (m.len > 1) ? m.msg[1] : 0xFF;
        printf("[CEC] RX  %s→%s  %-16s  [%s]\n",
               _addr_name(rsrc), _addr_name(rdst), _op_name(rop), rhex);
        fflush(stdout);
    }

    return tx_ok || !tx_nack;
}
