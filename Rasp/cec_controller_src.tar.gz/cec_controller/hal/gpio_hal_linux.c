/**
 * hal/gpio_hal_linux.c
 * ─────────────────────────────────────────────────────────────────────────────
 * GPIO HAL implementation for Raspberry Pi using libgpiod 1.x.
 *
 * libgpiod works on Pi kernel 6.x (RPi.GPIO edge-detection is broken there).
 *
 * Button wiring — all active-LOW, use internal pull-ups:
 *   GPIO17 (Pin 11) ──[BTN]── GND  →  GPIO_BTN_SOUNDBAR   (SAM ON)
 *   GPIO27 (Pin 13) ──[BTN]── GND  →  GPIO_BTN_TV         (SAM OFF)
 *   GPIO22 (Pin 15) ──[BTN]── GND  →  GPIO_BTN_VOL_DOWN
 *
 * To port to ESP32:
 *   Replace this file with hal/gpio_hal_esp32.c — implement gpio_hal_init,
 *   gpio_hal_poll, gpio_hal_close using Arduino digitalRead / INPUT_PULLUP.
 */

#include "../cec_controller.h"

#include <errno.h>
#include <gpiod.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* ── Pin assignments (BCM numbering) ────────────────────────────────────── */
static const unsigned int PIN_MAP[GPIO_COUNT] = {
    [GPIO_BTN_SOUNDBAR]  = 17,   /* Pin 11 → SAM ON  */
    [GPIO_BTN_TV]        = 27,   /* Pin 13 → SAM OFF */
    [GPIO_BTN_VOL_DOWN]  = 22,   /* Pin 15 → Vol-    */
};
static const char *PIN_LABEL[GPIO_COUNT] = {
    "soundbar", "tv-speakers", "vol-down",
};

#define DEBOUNCE_MS  300   /* ignore re-triggers within this window */
#define GPIOCHIP     "gpiochip0"

static struct gpiod_chip        *_chip = NULL;
static struct gpiod_line        *_lines[GPIO_COUNT];
static gpio_btn_callback_t       _cb   = NULL;
static long long                 _last_press_ms[GPIO_COUNT];

/* ── Millisecond clock ───────────────────────────────────────────────────── */
static long long _now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

/* ── Init ─────────────────────────────────────────────────────────────────── */
int gpio_hal_init(gpio_btn_callback_t cb) {
    _cb   = cb;
    _chip = gpiod_chip_open_by_name(GPIOCHIP);
    if (!_chip) {
        fprintf(stderr, "[GPIO] open(%s): %s\n", GPIOCHIP, strerror(errno));
        return -1;
    }

    for (int i = 0; i < GPIO_COUNT; i++) {
        _lines[i] = gpiod_chip_get_line(_chip, PIN_MAP[i]);
        if (!_lines[i]) {
            fprintf(stderr, "[GPIO] get_line(%u): %s\n", PIN_MAP[i], strerror(errno));
            return -1;
        }
        /* Input with pull-up bias (active-LOW buttons) */
        struct gpiod_line_request_config cfg = {
            .consumer     = PIN_LABEL[i],
            .request_type = GPIOD_LINE_REQUEST_DIRECTION_INPUT,
            .flags        = GPIOD_LINE_REQUEST_FLAG_BIAS_PULL_UP,
        };
        if (gpiod_line_request(_lines[i], &cfg, 0) < 0) {
            fprintf(stderr, "[GPIO] request(%s, GPIO%u): %s\n",
                    PIN_LABEL[i], PIN_MAP[i], strerror(errno));
            return -1;
        }
        _last_press_ms[i] = 0;
        printf("[GPIO] GPIO%u → %s\n", PIN_MAP[i], PIN_LABEL[i]);
    }
    return 0;
}

/* ── Poll (call from main loop) ──────────────────────────────────────────── */
void gpio_hal_poll(void) {
    long long now = _now_ms();
    for (int i = 0; i < GPIO_COUNT; i++) {
        int val = gpiod_line_get_value(_lines[i]);
        if (val < 0) continue;                   /* read error — skip */
        if (val == 0) {                           /* button pressed (active-LOW) */
            if ((now - _last_press_ms[i]) >= DEBOUNCE_MS) {
                _last_press_ms[i] = now;
                if (_cb) _cb((gpio_btn_t)i);
            }
        }
    }
}

/* ── Close ────────────────────────────────────────────────────────────────── */
void gpio_hal_close(void) {
    for (int i = 0; i < GPIO_COUNT; i++)
        if (_lines[i]) { gpiod_line_release(_lines[i]); _lines[i] = NULL; }
    if (_chip) { gpiod_chip_close(_chip); _chip = NULL; }
}
