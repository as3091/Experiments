/**
 * hal/cec_hal_esp32.c
 * ─────────────────────────────────────────────────────────────────────────────
 * CEC HAL stub for ESP32 (PlatformIO / Arduino framework).
 *
 * HOW TO PORT:
 *   1. Copy the entire cec_controller/ folder into your PlatformIO src/.
 *   2. In platformio.ini add:  build_flags = -DPLATFORM_ESP32
 *   3. Exclude hal/cec_hal_linux.c and hal/gpio_hal_linux.c from the build.
 *   4. Implement the three functions below using the existing ESP32_CEC library
 *      (lib/ESP32_CEC/) — or inline the bit-bang logic directly here.
 *
 * VERIFIED CEC SEQUENCES (same as Linux side):
 *   SAM ON:   [05 70 10 00]  TV(0)→SB(5) SAM_REQUEST phys=1.0.0.0
 *   SAM OFF:  [5F 72 00]     spoof SB→all SET_SAM OFF
 *             [0F 72 00]     TV→all       SET_SAM OFF
 *             [0F 82 00 00]  TV→all       ACTIVE_SOURCE(0.0.0.0)
 *
 * NOTE: On ESP32 you own the bus line directly (no kernel FL_RAW needed).
 *       Set the header byte to 0x05 (TV<<4|SB) and transmit — the soundbar
 *       cannot tell the difference from the real TV.
 */

#ifdef PLATFORM_ESP32
#include "../cec_controller.h"
#include "ESP32_CEC.h"   /* from lib/ESP32_CEC/ */

/* One global CEC instance — pin configured via CEC_GPIO_PIN in platformio.ini */
static ESP32CEC _cec(CEC_GPIO_PIN);

int cec_hal_open(const char *device) {
    (void)device;   /* unused on ESP32 — device is the GPIO pin */
    _cec.begin(CEC_ADDR_AUDIO_SYSTEM); /* claim Audio System addr for rx */
    Serial.println("[CEC] ESP32 CEC HAL ready");
    return 0;
}

void cec_hal_close(void) {
    /* nothing to close on ESP32 */
}

bool cec_hal_tx(const uint8_t *data, uint8_t len, uint8_t reply_op) {
    (void)reply_op;   /* ESP32 bit-bang TX is fire-and-forget; no kernel reply wait */

    Serial.printf("[CEC] TX [");
    for (int i = 0; i < len; i++) Serial.printf("%02X ", data[i]);
    Serial.println("]");

    /* Use the low-level _writeFrame via a thin wrapper.
     * Because _writeFrame is private, expose it by calling sendRaw() if you
     * add that method to ESP32_CEC, or duplicate the frame logic here.     */
    _cec.sendRaw(data, len);   /* add sendRaw(uint8_t*, uint8_t) to ESP32_CEC */
    return true;
}
#endif /* PLATFORM_ESP32 */
